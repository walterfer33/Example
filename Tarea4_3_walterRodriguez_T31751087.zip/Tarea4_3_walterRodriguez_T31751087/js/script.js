function LoginUsuario(){
    var Formulario = document.forms["formulario"];
    var email = Formulario["email"].value;
    var password = Formulario["password"].value;
    if(email !="" && password !=""){
    document.getElementById("error").style.display = "none";
    var existe = false;
    var lista_usuario = get_usuarios();
    lista_usuario.forEach(c => {

        if (c.email == email && c.password == password)

            existe = true;
            document.getElementById("error").style.display = "none";
            document.getElementById("inventario").style.display = "block";
            document.getElementById("login").style.display = "none";
    });


    if (existe == false) {
        document.getElementById("error").style.display = "block";
        document.getElementById("exito").style.display = "none";
        document.getElementById("inventario").style.display = "none";
        document.getElementById("mensaje").value = "Usuario o contraseña intcorrectos o usuario no existe";
        document.getElementById("paso1").style.display = "block";
    }
}else {
    document.getElementById("error").style.display = "block";
    document.getElementById("mensaje").value = "Debe llenar todos los campos";
}  
    return existe;
}


function validar_usuario(mail) {
    var valido = false;
    if (email != "" && !existe_usuario(mail)) {

        valido = true;

    } else {
        alert("Usuario vacío o ucupado, utilice otro")
    }
    return valido;
}

function existe_usuario(mail) {
    var existe = false;
    var usuarios = get_usuarios();
    usuarios.forEach(c => {

        if (c.email == mail)

            existe = true;
    });

    return existe;
}


function get_usuarios() {
    var lista_usuarios = [];
    var str_lista_usuarios = localStorage.getItem("usuarios");
    if (str_lista_usuarios) {

        lista_usuarios = JSON.parse(str_lista_usuarios);

    }

    return lista_usuarios;

}



function Paso1(){
document.getElementById("paso1").style.display = "none";
document.getElementById("paso_1").style.display = "block";
document.getElementById("iniciar").style.display = "none";
document.getElementById("login").style.display = "none";
document.getElementById("error").style.display = "none";
}

function validar_pass(pass1, pass2) {
    var valido = false;
    if (pass1 != "" && pass1 == pass2) {
        valido = true;
    } else {
        document.getElementById("error").style.display = "block";
        document.getElementById("mensaje").value = "Las constraseñas no coinciden";
 
    }

    return valido;
}



function Paso2() {
    var FormReg = document.forms["formulario"];
    var pass1 = FormReg["regpassword"].value;
    var pass2 = FormReg["confirmpassword"].value;
    var correo = FormReg["regemail"].value;
    if (validar_pass(pass1, pass2) && validar_correo(correo)) {
        document.getElementById("error").style.display = "none";
        document.getElementById("paso_2").style.display = "block";
        document.getElementById("paso_1").style.display = "none";

    }
}


function validar_correo(correo) {
    var valido = false;
    if (correo != "" && !existe_usuario(correo)) {

        valido = true;

    } else {
        document.getElementById("error").style.display = "block";
        document.getElementById("mensaje").value = "Correo en uso, utilice otro";
    }
    return valido;
}

function RegistrarUsuario(){
        var Formulario = document.forms["formulario"];
        var email = Formulario["regemail"].value;
        var password = Formulario["regpassword"].value;
        var ncompleto = Formulario["regncompleto"].value;
        var identidad = Formulario["regidentidad"].value;
        var departamento = Formulario["regdepartamento"].value;
        var condiciones = Formulario["regcondiciones"].value;
    if(ncompleto !="" && identidad !="" && departamento !="" && condiciones !="" && identidad.length == 13){
        document.getElementById("error").style.display = "none";
   var usuarios = {email:email,password:password,ncompleto:ncompleto,identidad:identidad,departamento:departamento};
    var usuarios_guardados = [];

    var usuarios_localstorage = localStorage.getItem("usuarios");
    if(usuarios_localstorage){
        usuarios_guardados = JSON.parse(usuarios_localstorage);
        usuarios_guardados.push(usuarios);
    }else{
        usuarios_guardados = [usuarios];
    }
    localStorage.setItem("usuarios",JSON.stringify(usuarios_guardados)); 
    document.getElementById("exito").style.display = "block";
    }else{
        document.getElementById("error").style.display = "block";
        document.getElementById("mensaje").value = "Hay campos vacios";      
    }
    return false;
    }


    function ObtenerDepartamento(valor){
        var departamento = valor.substr(0,2);
        var Formulario = document.forms["formulario"];
        var select = Formulario["regdepartamento"];
        var array = [["01","Atlántida"],
        ["02","Colón"],
        ["03","Comayagua"],
        ["04","Copán"],
        ["05","Cortés"],
        ["06","Choluteca"],
        ["07","El Paraíso"],
        ["08","Francisco Morazán"],
        ["09","Gracias a Dios"],
        ["10","Intibucá"],
        ["11","Islas de la Bahía"],
        ["12","La Paz"],
        ["13","Lempira"],
        ["14","Ocotepeque"],
        ["15","Olancho"],
        ["16","Santa Bárbara"],
        ["17","Valle"],
        ["18","Yoro"]];
        select.options.length = 0;
        for( var i = 0, len = array.length; i < len; i++ ) {
            if(array[i][0]==departamento.toString()){
            select.remove(select.appendChild);
            var depto = array[i][1];
            break;
            }
        }
        var opt = document.createElement('option');
        opt.value = depto;
        opt.innerHTML = depto;
        select.appendChild(opt);
    }



    function GuardarDatos(){
        var Formulario = document.forms["formulario"];
        var sku = Formulario["regsku"].value;
        var nombre = Formulario["regnombre"].value;
        var precio = Formulario["regprecio"].value;
        var foto = Formulario["regfoto"].value;
        var descripcion = Formulario["regdescripcion"].value;
        if(sku !="" && nombre !="" && precio !="" && foto !="" && descripcion !=""){
            var articulos = {sku:sku,nombre:nombre,precio:precio,foto:foto,descripcion:descripcion};
            var articulos_guardados = [];
        
            var articulos_localstorage = localStorage.getItem("articulos");
            if(articulos_localstorage){
                articulos_guardados = JSON.parse(articulos_localstorage);
                articulos_guardados.push(articulos);
            }else{
                articulos_guardados = [articulos];
            }
        localStorage.setItem("articulos",JSON.stringify(articulos_guardados)); 
        Formulario["limpiar"].click();
        window.alert("Articulo registrado");
        
        
        var historial_actual =localStorage.getItem("articulos");
        var lista = JSON.parse(historial_actual);
        var cuerpo_tabla = document.getElementById("cuerpo_tabla");
        cuerpo_tabla.innerHTML = "";  
        lista.forEach(producto => {     
            var fila = document.createElement("tr"); 
            var celda = document.createElement("td"); 

            celda.innerHTML = producto.sku;
            fila.appendChild(celda);  

            var sku = producto.sku;

            var celda = document.createElement("td"); 

            celda.innerHTML = producto.nombre;
            fila.appendChild(celda);  

            var nombre = producto.nombre;

            var celda = document.createElement("td"); 

            celda.innerHTML = producto.precio;
            fila.appendChild(celda);  

            var precio = producto.precio;

            var celda = document.createElement("td"); 
            var imagen = document.createElement("img");
            imagen.src = producto.foto;
            imagen.style.width = "90px";
            celda.appendChild(imagen);
            fila.appendChild(celda);  
            
            

            var celda = document.createElement("td"); 

            celda.innerHTML = producto.descripcion;
            fila.appendChild(celda);  


            var celda = document.createElement("td"); 
            var boton = document.createElement("input");
            boton.type = "submit";
            boton.value = "+";
            boton.className ="btn btn-success";
            boton.onclick = function () {GuardarFila(sku,nombre,precio,1)}
            celda.appendChild(boton);
            fila.appendChild(celda); 

            cuerpo_tabla.appendChild(fila);        
        });

        }else{
           window.alert("Debe llenar todos los campos"); 
        }

    }



     function GuardarFila(sku,nombre,precio,cantidad) {
         var total = cantidad * precio;
         var sum;
        var articulos = {sku:sku,nombre:nombre,precio:precio,total:total};
        var articulos_guardados = [];
    
        var articulos_localstorage = localStorage.getItem("carrito");
        if(articulos_localstorage){
            articulos_guardados = JSON.parse(articulos_localstorage);
            articulos_guardados.push(articulos);
        }else{
            articulos_guardados = [articulos];
        }
        localStorage.setItem("carrito",JSON.stringify(articulos_guardados)); 
        var historial_actual =localStorage.getItem("carrito");
        var lista = JSON.parse(historial_actual);
        var cuerpo_tabla = document.getElementById("carrito_tabla");
        cuerpo_tabla.innerHTML = "";  
        lista.forEach(producto => {     
            var fila = document.createElement("tr"); 
            var celda = document.createElement("td"); 

            celda.innerHTML = producto.sku;
            fila.appendChild(celda);  

            var celda = document.createElement("td"); 

            celda.innerHTML = producto.nombre;
            fila.appendChild(celda);  


            var celda = document.createElement("td"); 

            celda.innerHTML = producto.precio;
            fila.appendChild(celda); 
            
            
            var celda = document.createElement("td"); 

            celda.innerHTML = cantidad;
            fila.appendChild(celda); 

            var celda = document.createElement("td"); 
            var total = cantidad*producto.precio;
            celda.innerHTML = total;
            fila.appendChild(celda); 

            cuerpo_tabla.appendChild(fila);   
            sum += total;     
        });
          document.getElementById("total_carrito").value = sum;  
         window.alert("Producto " + sku + "agregado al carrito");
        }

        function VaciarCarrito(){
            localStorage.setItem("carrito","");
            var tabla = document.getElementById("carrito_tabla");
            tabla.innerHTML = "";
            window.alert("Compra realizada con exito");
        }
    